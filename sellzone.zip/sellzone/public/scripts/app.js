'use strict';

angular.module('transMApp', ['ui.router', 'ngResource', 'nvd3', 'mwl.confirm'])
.config(function($stateProvider, $urlRouterProvider) {
        $stateProvider

            // route for the home page
            .state('app', {
                url:'/',
                views: {
                    'header': {
                        templateUrl : 'views/header.html',
                    },
                    'content@': {
                        templateUrl : 'views/home.html'
                    },
                    'footer': {
                        templateUrl : 'views/footer.html',
                    }
                }

            })

            // Init Payment
            .state('app.initpayment', {
                url:'initpayment',
                views: {
                    'content@': {
                        templateUrl : 'views/initpayment.html',
                        controller  : 'InitPaymentController'
                    }
                },
                params: {
                    price: null
                }
            })
        
            // Item Detail
            .state('app.itemdetail', {
                url:'itemdetail',
                views: {
                    'content@': {
                        templateUrl : 'views/itemdetail.html',
                        controller  : 'ItemDetailController'
                    }
                }

            })

        
            // route for the aboutus page
            .state('app.aboutus', {
                url:'aboutus',
                views: {
                    'content@': {
                        templateUrl : 'views/aboutus.html'
                    }
                }
            })

            // route for the login page
            .state('app.login', {
                url:'login',
                views: {
                    'content@': {
                        templateUrl : 'views/login.html',
                        controller  : 'UserController'
                    }
                }
            })
        
            // route for the admin register page
            .state('app.register', {
                url:'register/admin/010265/secret',
                views: {
                    'content@': {
                        templateUrl : 'views/register.html',
                        controller  : 'UserController'
                    }
                }
            })

            // route for the add user page
            .state('app.adduser', {
                url:'addUser',
                views: {
                    'content@': {
                        templateUrl : 'views/adduser.html',
                        controller  : 'AddUserController'
                    }
                }
            })

            // route for the add transformer page
            .state('app.addtransformer', {
                url:'addtransformer',
                views: {
                    'content@': {
                        templateUrl : 'views/addtransformer.html',
                        controller  : 'AddTransformerController'
                    }
                }
            })

            // route for the add transformer page
            .state('app.linkuser', {
                url:'linkuser',
                views: {
                    'content@': {
                        templateUrl : 'views/linkuser.html',
                        controller  : 'LinkUserController'
                    }
                }
            })

            .state('app.unlinkuser', {
                url:'unlinkuser',
                views: {
                    'content@': {
                        templateUrl : 'views/unlinkuser.html',
                        controller  : 'UnlinkUserController'
                    }
                }
            })

            .state('app.removetransformer', {
                url:'removetransformer',
                views: {
                    'content@': {
                        templateUrl : 'views/removetransformer.html',
                        controller  : 'RemoveTransformerController'
                    }
                }
            })

            .state('app.reset', {
                url:'resetPassword',
                views: {
                    'content@': {
                        templateUrl : 'views/reset.html',
                        controller  : 'UserController'
                    }
                }
            })

            .state('app.removeuser', {
                url:'removeuser',
                views: {
                    'content@': {
                        templateUrl : 'views/removeuser.html',
                        controller  : 'UserController'
                    }
                }
            })

            .state('app.usersunderadmin', {
                url:'usersunderadmin',
                views: {
                    'content@': {
                        templateUrl : 'views/usersunderadmin.html',
                        controller  : 'UsersUnderAdminController'
                    }
                }
            })

            .state('app.userlinkedtotransformer', {
                url:'userlinkedtotransformer/:transformerId',
                views: {
                    'content@': {
                        templateUrl : 'views/userlinkedtotransformer.html',
                        controller  : 'UserLinkedToTransformerController'
                    }
                }
            })

            // route for the contactus page
            .state('app.contactus', {
                url:'contactus',
                views: {
                    'content@': {
                        templateUrl : 'views/contactus.html'
                    }
                }
            });

        $urlRouterProvider.otherwise('/');
    })
;
